<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.student.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.student.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
    <div class="row">
        <div class="col-sm-7 col-4">
            <h4 class="page-title">Update Information</h4>
        </div>
    </div>
    <div class="card-box">
        <div class="row">
            <div class="offset-md-2 col-md-7">
              <div class="card-box">
                <?php if(session('status')): ?>
                  <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                  </div>
                <?php endif; ?>

                <div class="profile-view">
                    <form class="" action="<?php echo e(route('studentprofileedit')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">Name</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($old_info->name); ?>">
                              <?php if($errors->has('name')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('name')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">E-mail</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($old_info->email); ?>">
                              <?php if($errors->has('email')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('email')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">Phone</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" value="<?php echo e(App\student_info::where('user_id', '=', Auth::user()->id)->firstorFail()->phone); ?>">
                              <?php if($errors->has('phone')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('phone')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">SSC Year</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('ssc_year') ? ' is-invalid' : ''); ?>" name="ssc_year" value="<?php echo e(App\student_info::where('user_id', '=', Auth::user()->id)->firstorFail()->ssc_year); ?>">
                              <?php if($errors->has('ssc_year')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('ssc_year')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">SSC GPA</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('ssc_gpa') ? ' is-invalid' : ''); ?>" name="ssc_gpa" value="<?php echo e(App\student_info::where('user_id', '=', Auth::user()->id)->firstorFail()->ssc_gpa); ?>">
                              <?php if($errors->has('ssc_gpa')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('ssc_gpa')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">HSC Year</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('hsc_year') ? ' is-invalid' : ''); ?>" name="hsc_year" value="<?php echo e(App\student_info::where('user_id', '=', Auth::user()->id)->firstorFail()->hsc_year); ?>">
                              <?php if($errors->has('hsc_year')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('hsc_year')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">HSC GPA</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('hsc_gpa') ? ' is-invalid' : ''); ?>" name="hsc_gpa" value="<?php echo e(App\student_info::where('user_id', '=', Auth::user()->id)->firstorFail()->hsc_gpa); ?>">
                              <?php if($errors->has('hsc_gpa')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('hsc_gpa')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">Group</label>
                          <div class="col-md-10">
                              <select class="form-control" name="group">
                                <option>--Select--</option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($group->id); ?>"><?php echo e($group->group_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">Adress</label>
                          <div class="col-md-10">
                              <textarea type="text" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" ><?php echo e(App\student_info::where('user_id', '=', Auth::user()->id)->firstorFail()->address); ?></textarea>
                              <?php if($errors->has('address')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('address')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="text-center m-auto">
                        <button type="submit" class="btn btn-primary">Update Info</button>
                      </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>