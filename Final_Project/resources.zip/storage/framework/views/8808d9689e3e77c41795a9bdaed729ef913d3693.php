<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">Add New Question</h4>
      </div>
  </div>
  <div class="row">
      <div class="offset-md-2 col-md-6">
          <div class="card-box">
            <?php if(session('status')): ?>
              <div class="alert alert-success">
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>
              <h4 class="card-title">Add New Question</h4>
              <form action="<?php echo e(route('addnewquestion')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                  <label class="col-form-label col-md-3"> Select Subject</label>
                    <div class="col-md-9">
                        <select class="form-control" name="exam_subject_id">
                            <option>-- Select --</option>
                            <?php $__currentLoopData = $exam_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam_subjects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($exam_subjects->id); ?>"><?php echo e($exam_subjects->exam_subject_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label  class="col-form-label col-md-3">Question</label>
                    <div class="col-md-9">
                      <textarea class="form-control<?php echo e($errors->has('question') ? ' is-invalid' : ''); ?>" placeholder="Enter Question" name="question" required><?php echo e(old('question')); ?></textarea>
                      <?php if($errors->has('question')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('question')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label  class="col-form-label col-md-3">Option 1</label>
                    <div class="col-md-9">
                      <input type="text" class="form-control<?php echo e($errors->has('option_1') ? ' is-invalid' : ''); ?>" placeholder="Enter Option 1" name="option_1" value="<?php echo e(old('option_1')); ?>" required>
                      <?php if($errors->has('option_1')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('option_1')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label  class="col-form-label col-md-3">Option 2</label>
                    <div class="col-md-9">
                      <input type="text" class="form-control<?php echo e($errors->has('options_2') ? ' is-invalid' : ''); ?>" placeholder="Enter Option 2" name="option_2" value="<?php echo e(old('options_2')); ?>" required>
                      <?php if($errors->has('options_2')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('options_2')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label  class="col-form-label col-md-3">Option 3</label>
                    <div class="col-md-9">
                      <input type="text" class="form-control<?php echo e($errors->has('options_3') ? ' is-invalid' : ''); ?>" placeholder="Enter Option 3" name="option_3" value="<?php echo e(old('options_3')); ?>" required>
                      <?php if($errors->has('options_3')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('options_3')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label  class="col-form-label col-md-3">Option 4</label>
                    <div class="col-md-9">
                      <input type="text" class="form-control<?php echo e($errors->has('options_4') ? ' is-invalid' : ''); ?>" placeholder="Enter Option 4" name="option_4" value="<?php echo e(old('options_4')); ?>" required>
                      <?php if($errors->has('options_4')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('options_4')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label  class="col-form-label col-md-3">Correct Answer</label>
                    <div class="col-md-9">
                      <input type="text" class="form-control<?php echo e($errors->has('correct_ans') ? ' is-invalid' : ''); ?>" placeholder="Enter Correct Answer" name="correct_ans" value="<?php echo e(old('correct_ans')); ?>" required>
                      <?php if($errors->has('correct_ans')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('correct_ans')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="text-center m-auto">
                    <button type="submit" class="btn btn-primary">Add Question</button>
                </div>
              </form>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>