<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <h4 class="page-title">Change Password</h4>
            <?php if(session('status')): ?>
              <div class="alert alert-success">
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>
            
            <form method="post" action="<?php echo e(route('changepasswordupdate')); ?>">
              <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Old password</label>
                            <input type="password" id="old_password" class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" name="old_password">
                            <?php if($errors->has('old_password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('old_password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>New password</label>
                            <input type="password" id="new_password" class="form-control<?php echo e($errors->has('new_password') ? ' is-invalid' : ''); ?>" name="new_password">
                            <?php if($errors->has('new_password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('new_password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Confirm password</label>
                            <input type="password" id="confirm_password" class="form-control<?php echo e($errors->has('confirm_password') ? ' is-invalid' : ''); ?>" name="confirm_password">
                            <?php if($errors->has('confirm_password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('confirm_password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 text-center m-t-20">
                        <button type="submit" class="btn btn-primary btn-lg">Update Password</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>