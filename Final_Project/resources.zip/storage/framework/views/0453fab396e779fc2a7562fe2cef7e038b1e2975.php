<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">Add New University</h4>
      </div>
  </div>
  <div class="row">
      <div class="offset-md-2 col-md-6">
          <div class="card-box">
            <?php if(session('status')): ?>
              <div class="alert alert-success">
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>
              <h4 class="card-title">Add New</h4>
              <form action="<?php echo e(route('university.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                  <div class="form-group">
                      <label>University Name</label>
                      <input type="text" class="form-control<?php echo e($errors->has('university_name') ? ' is-invalid' : ''); ?>" placeholder="Enter new University name" name="university_name" value="<?php echo e(old('university_name')); ?>">
                      <?php if($errors->has('university_name')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('university_name')); ?></strong>
                          </span>
                      <?php endif; ?>
                  </div>
                  <div class="text-center m-auto">
                      <button type="submit" class="btn btn-primary">Add University</button>
                  </div>
              </form>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>