<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">All Job Circular</h4>
      </div>
  </div>
  <div class="row">
      <div class="offset-sm-2 col-sm-8">
          <div class="card-box">
              <div class="card-block">
                  <h6 class="card-title text-bold">Job Circulars List</h6>
                  <table class="datatable table table-stripped table-responsive">
                    <?php if(session('status')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                      </div>
                    <?php endif; ?>
                      <thead>
                          <tr>
                              <th>No.</th>
                              <th>Details</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php
                          $i=1;
                        ?>
                          <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($job->details); ?></td>
                                <td>
                                  <a target="_blank" href="<?php echo e(asset('storage')); ?>/<?php echo e($job->circular); ?>" class="btn btn-danger text-white"> <i class="fa fa-eye"></i></a>
                                  <a href="<?php echo e(url('job/delete')); ?>/<?php echo e($job->id); ?>" class="btn btn-danger text-white"> <i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>