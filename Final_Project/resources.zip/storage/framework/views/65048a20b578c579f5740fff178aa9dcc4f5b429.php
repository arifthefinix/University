<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">List of all Units</h4>
      </div>
  </div>
  <div class="row">
      <div class="col-sm-12">
          <div class="card-box">
              <div class="card-block">
                  <h6 class="card-title text-bold">University Unit List</h6>
                  <?php if(session('status')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                    </div>
                  <?php endif; ?>
                  <table class="datatable table table-stripped table-responsive">
                      <thead>
                          <tr>
                              <th>No.</th>
                              <th>Name</th>
                              <th>University Name</th>
                              <th>Required GPA</th>
                              <th>Group Name</th>
                              <th>Application Deadline</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php
                          $i=1;
                        ?>
                          <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($unit->unit_name); ?></td>
                                <td><?php echo e(App\University::find($unit->university_id)->university_name); ?></td>
                                <td><?php echo e($unit->gpa); ?></td>
                                <td><?php echo e(App\Group::find($unit->group_id)->group_name); ?></td>
                                <td><?php echo e($unit->application_deadline); ?></td>
                                <td>
                                  <a href="#exampleModalCenter<?php echo e(++$key); ?>" data-toggle="modal" class="btn btn-info" title="Show Details"> <i class="fa fa-eye"></i></a>
                                  <a href="<?php echo e(url('unit/edit')); ?>/<?php echo e($unit->id); ?>" class="btn btn-warning"> <i class="fa fa-pencil"></i></a>
                                  <a href="<?php echo e(url('unit/delete')); ?>/<?php echo e($unit->id); ?>" class="btn btn-danger"> <i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>

              <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="modal fade" id="exampleModalCenter<?php echo e(++$key); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Details About <?php echo e($unit->unit_name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="">
                          <h4>University Name</h4>
                          <p><?php echo e(App\University::find($unit->university_id)->university_name); ?></p>
                        </div>
                        <div class="">
                          <h4>Group Name</h4>
                          <p><?php echo e(App\Group::find($unit->group_id)->group_name); ?></p>
                        </div>
                        <div class="">
                          <h4>Required GPA</h4>
                          <p><?php echo e($unit->gpa); ?></p>
                        </div>
                        <div class="">
                          <h4>Application Deadline</h4>
                          <p><?php echo e($unit->application_deadline); ?></p>
                        </div>
                        <div class="">
                          <h4>Exam Date</h4>
                          <p><?php echo e($unit->exam_date); ?></p>
                        </div>
                        <div class="">
                          <h4>Exam Fee</h4>
                          <p><?php echo e($unit->fee); ?></p>
                        </div>
                        <div class="">
                          <h4>Total NUmber of Seats</h4>
                          <p><?php echo e($unit->seat); ?></p>
                        </div>
                        <div class="">
                          <h4>Apply Process</h4>
                          <p><?php echo e($unit->apply_process); ?></p>
                        </div>
                      </div>
                      <div class="modal-footer m-auto">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>