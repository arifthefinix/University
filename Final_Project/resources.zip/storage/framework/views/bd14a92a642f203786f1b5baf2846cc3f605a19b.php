<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">All Questions List</h4>
      </div>
  </div>
  <div class="row">
      <div class="offset-sm-1 col-sm-9">
          <div class="card-box">
              <div class="card-block">
                  <?php if(session('status')): ?>
                    <div class="alert alert-danger">
                      <?php echo e(session('status')); ?>

                    </div>
                  <?php endif; ?>
                  <h6 class="card-title text-bold">Questions</h6>
                  <table class="datatable table table-stripped table-responsive text-center">
                      <thead>
                          <tr>
                              <th>No.</th>
                              <th>Question</th>
                              <th>Subject</th>
                              <th>Options</th>
                              <th>Correct Ans.</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php
                          $i=1;
                        ?>
                          <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($question->question); ?></td>
                                <td><?php echo e($question->getExamSubject->exam_subject_name); ?></td>
                                <td>
                                  <ul>
                                    <li><?php echo e($question->getAnswer->option_1); ?></li>
                                    <li><?php echo e($question->getAnswer->option_2); ?></li>
                                    <li><?php echo e($question->getAnswer->option_3); ?></li>
                                    <li><?php echo e($question->getAnswer->option_4); ?></li>
                                  </ul>
                                </td>
                                <td><?php echo e($question->getAnswer->correct_ans); ?></td>
                                <td>
                                  <a href="<?php echo e(url('question/delete')); ?>/<?php echo e($question->id); ?>" title="Delete" class="btn btn-danger"> <i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>