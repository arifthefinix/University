<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">List of all Subjects</h4>
      </div>
  </div>
  <div class="row">
      <div class="col-sm-12">
          <div class="card-box">
              <div class="card-block">
                  <h6 class="card-title text-bold">Subject List</h6>
                  <?php if(session('status')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                    </div>
                  <?php endif; ?>
                  <table class="datatable table table-stripped text-center">
                      <thead>
                          <tr>
                              <th>No.</th>
                              <th>Name</th>
                              <th>University Name</th>
                              <th>Group Name</th>
                              <th>Number of seats</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($subject->subject_name); ?></td>
                                <td><?php echo e(App\University::find($subject->university_id)->university_name); ?></td>
                                <td><?php echo e(App\Group::find($subject->group_id)->group_name); ?></td>
                                <td><?php echo e($subject->seat); ?></td>
                                <td>
                                  <a href="<?php echo e(url('subject/edit')); ?>/<?php echo e($subject->id); ?>" class="btn btn-warning"> <i class="fa fa-pencil"></i></a>
                                  <a href="<?php echo e(url('subject/delete')); ?>/<?php echo e($subject->id); ?>" class="btn btn-danger"> <i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>