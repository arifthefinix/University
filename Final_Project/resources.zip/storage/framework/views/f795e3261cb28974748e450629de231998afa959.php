<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">All Notifications</h4>
      </div>
  </div>
  <div class="row">
      <div class="offset-sm-1 col-sm-9">
          <div class="card-box">
              <div class="card-block">
                  <?php if(session('status')): ?>
                    <div class="alert alert-danger">
                      <?php echo e(session('status')); ?>

                    </div>
                  <?php endif; ?>
                  <h6 class="card-title text-bold">Notifications</h6>
                  <a href="<?php echo e(route('alladminnotification')); ?>" class="btn btn-primary float-right">View all</a>
                  <table class="datatable table table-stripped table-responsive text-center">
                      <thead>
                          <tr>
                              <th>No.</th>
                              <th>Notification Text</th>
                              <th>Created at</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php
                          $i=1;
                        ?>
                          <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($notification->admin_notification_text); ?></td>
                                <td><?php echo e($notification->created_at->diffForHumans()); ?></td>
                                <td>
                                  <a href="<?php echo e(url('admin/notification/markread')); ?>/<?php echo e($notification->id); ?>" title="Mark as read" class="btn btn-primary"> <i class="fa fa-check"></i></a>
                                  <a href="<?php echo e(url('admin/notification/delete')); ?>/<?php echo e($notification->id); ?>" title="Delete" class="btn btn-danger"> <i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>