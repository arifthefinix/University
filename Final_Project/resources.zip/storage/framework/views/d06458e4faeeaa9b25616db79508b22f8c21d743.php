<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title"> Update<span class="text-primary"> <?php echo e($old_info->unit_name); ?></span> Subject</h4>
      </div>
  </div>
  <div class="row">
      <div class="offset-md-2 col-md-6">
          <div class="card-box">
            <?php if(session('status')): ?>
              <div class="alert alert-success">
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>
              <h4 class="card-title">Update Subject</h4>
              <form action="<?php echo e(route('subjectupdate')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                  <label class="col-form-label col-md-3"> Select University</label>
                    <div class="col-md-9">
                        <select class="form-control" name="university_id">
                            <option>-- Select --</option>
                            <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($university->id); ?>"><?php echo e($university->university_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                  <label class="col-form-label col-md-3"> Select Unit</label>
                    <div class="col-md-9">
                        <select class="form-control" name="unit_id">
                            <option>-- Select --</option>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->unit_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                  <label class="col-form-label col-md-3"> Select Group</label>
                    <div class="col-md-9">
                        <select class="form-control" name="group_id" required>
                            <option>-- Select --</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($group->id); ?>"><?php echo e($group->group_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label  class="col-form-label col-md-3">Subject Name</label>
                    <div class="col-md-9">
                      <input type="text" class="form-control<?php echo e($errors->has('subject_name') ? ' is-invalid' : ''); ?>" placeholder="Enter Subject Name" name="subject_name" value="<?php echo e($old_info->subject_name); ?>" required>
                      <input type="hidden" name="subject_id" value="<?php echo e($old_info->id); ?>">
                      <?php if($errors->has('subject_name')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('subject_name')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label  class="col-form-label col-md-3">Number of Seats</label>
                    <div class="col-md-9">
                      <input type="text" class="form-control<?php echo e($errors->has('seat') ? ' is-invalid' : ''); ?>" placeholder="Enter Number of seats" name="seat" value="<?php echo e($old_info->seat); ?>" required>
                      <?php if($errors->has('seat')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('seat')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="text-center m-auto">
                    <button type="submit" class="btn btn-primary">Update Subject</button>
                </div>
              </form>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>