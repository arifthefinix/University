<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
    <div class="row">
        <div class="col-sm-7 col-4">
            <h4 class="page-title">Update Information</h4>
        </div>
    </div>
    <div class="card-box">
        <div class="row">
            <div class="offset-md-3 col-md-6">
              <div class="card-box">
                <?php if(session('status')): ?>
                  <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                  </div>
                <?php endif; ?>
                <div class="profile-view">
                    <form class="" action="<?php echo e(route('adminprofileedit')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">Name</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($old_info->name); ?>">
                              <?php if($errors->has('name')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('name')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-form-label col-md-2">E-mail</label>
                          <div class="col-md-10">
                              <input type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($old_info->email); ?>">
                              <?php if($errors->has('email')): ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('email')); ?></strong>
                                  </span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="text-center m-auto">
                        <button type="submit" class="btn btn-primary">Update Info</button>
                      </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>