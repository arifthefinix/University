<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/back_end')); ?>/assets/img/favicon.png">
    <title>Student || Registration</title>
    <link href="https://fonts.googleapis.com/css?family=Fira+Sans:400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/back_end')); ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/back_end')); ?>/assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/back_end')); ?>/assets/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/back_end')); ?>/assets/css/style.css">

</head>

<body>
    <div class="main-wrapper">
        <div class="account-page">
            <div class="container">
                <h3 class="account-title"><?php echo e(__('Student Registration Form')); ?></h3>
                <div class="account-box">
                    <div class="account-wrapper">
                        <div class="account-logo">
                            <a href="#"><img src="<?php echo e(asset('/back_end')); ?>/assets/img/logo2.png" alt="Preadmin"></a>
                        </div>
                        <?php if($errors->any()): ?>
                          <div class="alert alert-danger">
                              <ul>
                                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li><?php echo e($error); ?></li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          </div>
                      <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('studentregister')); ?>">
                          <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="col-form-label">Name</label>
                                <div class="col-md-12">
                                  <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('E-mail Address')); ?></label>
                                <div class="col-md-12">
                                  <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('Phone Number')); ?></label>
                                <div class="col-md-12">
                                  <input id="phone" type="text" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" value="<?php echo e(old('phone')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('phone')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('Date of Birth')); ?></label>
                                <div class="col-md-12">
                                  <input id="dob" type="text" class="datetimepicker form-control<?php echo e($errors->has('dob') ? ' is-invalid' : ''); ?>" name="dob" value="<?php echo e(old('dob')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('dob')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('dob')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('Gender')); ?></label>
                                <div class="col-md-12">
                                  <select id="gender" class="form-control" name="gender" value="<?php echo e(old('gender')); ?>" required autofocus>
                                    <option >--Select--</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Others">Others</option>
                                  </select>
                              </div>
                                <?php if($errors->has('gender')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('gender')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('SSC Year')); ?></label>
                                <div class="col-md-12">
                                  <input id="ssc_year" type="text" class="form-control<?php echo e($errors->has('ssc_year') ? ' is-invalid' : ''); ?>" name="ssc_year" value="<?php echo e(old('ssc_year')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('ssc_year')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('ssc_year')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('SSC GPA')); ?></label>
                                <div class="col-md-12">
                                  <input id="ssc_gpa" type="text" class="form-control<?php echo e($errors->has('ssc_gpa') ? ' is-invalid' : ''); ?>" name="ssc_gpa" value="<?php echo e(old('ssc_gpa')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('ssc_gpa')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('ssc_gpa')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('HSC Year')); ?></label>
                                <div class="col-md-12">
                                  <input id="hsc_year" type="text" class="form-control<?php echo e($errors->has('hsc_year') ? ' is-invalid' : ''); ?>" name="hsc_year" value="<?php echo e(old('hsc_year')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('hsc_year')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('ssc_year')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('HSC GPA')); ?></label>
                                <div class="col-md-12">
                                  <input id="hsc_gpa" type="text" class="form-control<?php echo e($errors->has('hsc_gpa') ? ' is-invalid' : ''); ?>" name="hsc_gpa" value="<?php echo e(old('hsc_gpa')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('hsc_gpa')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('hsc_gpa')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('Select Group')); ?></label>
                                <div class="col-md-12">
                                  <select id="group" class="form-control<?php echo e($errors->has('group') ? ' is-invalid' : ''); ?>" name="group" value="<?php echo e(old('group')); ?>" required autofocus>
                                  <option>--Select--</option>
                                  <option value="1">Science</option>
                                  <option value="2">Commerce</option>
                                  <option value="3">Arts</option>
                                </select>
                                </div>
                                <?php if($errors->has('group')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('group')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('Address')); ?></label>
                                <div class="col-md-12">
                                  <textarea id="address" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" required autofocus><?php echo e(old('address')); ?></textarea>
                                </div>
                                <?php if($errors->has('address')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('Password')); ?></label>
                                <div class="col-md-12">
                                  <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" value="<?php echo e(old('password')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label"><?php echo e(__('Conform Password')); ?></label>
                                <div class="col-md-12">
                                  <input id="password_confirmation" type="password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button class="btn btn-primary btn-block account-btn" type="submit"><?php echo e(__('Register')); ?></button>
                            </div>
                            <div class="text-center">
                                <a href="<?php echo e(route('login')); ?>">Already have an account?</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/jquery-3.2.1.min.js"></script>
	  <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/popper.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/bootstrap-datetimepicker.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/app.js"></script>
</body>
</html>
