<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/back_end')); ?>/assets/img/favicon.png">
    <title>Admission Help Desk || Login</title>
    <link href="https://fonts.googleapis.com/css?family=Fira+Sans:400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/back_end')); ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/back_end')); ?>/assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/back_end')); ?>/assets/css/style.css">
</head>

<body>
    <div class="main-wrapper">
        <div class="account-page">
            <div class="container">
                <h3 class="account-title"><?php echo e(__('Login')); ?></h3>
                <div class="account-box">
                    <div class="account-wrapper">
                        <div class="account-logo">
                            <a href="#"><img src="<?php echo e(asset('/back_end')); ?>/assets/img/logo2.png" alt="Preadmin"></a>
                        </div>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                          <?php echo csrf_field(); ?>
                            <div class="form-group form-focus">
                                <label class="focus-label"><?php echo e(__('E-Mail Address')); ?></label>
                                <input class="form-control floating <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus type="email">
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group form-focus">
                                <label class="focus-label"><?php echo e(__('Password')); ?></label>
                                <input id="password" type="password" class="form-control floating<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group form-focus text-center">
                              <label class="form-check-label text-center" for="remember">
                                  <?php echo e(__('Remember Me')); ?> &nbsp;&nbsp;&nbsp;
                              </label>
                              <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            </div>
                            <div class="form-group text-center">
                                <button class="btn btn-primary btn-block account-btn" type="submit"><?php echo e(__('Login')); ?></button>
                            </div>
                            <div class="text-center">
                                <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Your Password?')); ?></a>
                            </div>
                            <div class="text-center">
                                <a href="<?php echo e(route('register')); ?>"> New user?? Regester Here</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/jquery-3.2.1.min.js"></script>
	  <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/popper.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('/back_end')); ?>/assets/js/app.js"></script>
</body>
</html>
