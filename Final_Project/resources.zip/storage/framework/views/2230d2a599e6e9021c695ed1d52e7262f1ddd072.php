<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">Update Group</h4>
      </div>

  </div>
  <div class="row">
      <div class="offset-md-2 col-md-6">
          <div class="card-box">
            <?php if(session('status')): ?>
              <div class="alert alert-success">
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>
              <h4 class="card-title">Update <span class="text-primary"> <?php echo e($old_info->group_name); ?></span></h4>
              <form action="<?php echo e(url('group/update')); ?>" method="post">
                <?php echo csrf_field(); ?>
                  <div class="form-group">
                      <label>Group Name</label>
                      <input type="hidden"  name="group_id" value="<?php echo e($old_info->id); ?>">
                      <input type="text" class="form-control<?php echo e($errors->has('group_name') ? ' is-invalid' : ''); ?>" placeholder="Enter new group name" name="group_name" value="<?php echo e($old_info->group_name); ?>">
                      <?php if($errors->has('group_name')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('group_name')); ?></strong>
                          </span>
                      <?php endif; ?>
                  </div>
                  <div class="text-center m-auto">
                      <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
              </form>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>