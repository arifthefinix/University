<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">All Images of Universities</h4>
      </div>
  </div>
  <div class="row">
      <div class="offset-sm-2 col-sm-8">
          <div class="card-box">
              <div class="card-block">
                  <h6 class="card-title text-bold">Image List</h6>
                  <table class="datatable table table-stripped table-responsive">
                    <?php if(session('status')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                      </div>
                    <?php endif; ?>
                      <thead>
                          <tr>
                              <th>No.</th>
                              <th>Image</th>
                              <th>University Name</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php
                          $i=1;
                        ?>
                          <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><img src="<?php echo e(asset('/storage')); ?>/<?php echo e($image->image_name); ?>" width="150px" class="img_fluid" alt=""></td>
                                <td><?php echo e(App\University::find($image->university_id)->university_name); ?></td>
                                <td>
                                  <a href="<?php echo e(url('university/image/delete')); ?>/<?php echo e($image->id); ?>" class="btn btn-danger text-white"> <i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>