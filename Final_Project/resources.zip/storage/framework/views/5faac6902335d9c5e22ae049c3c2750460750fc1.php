<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">Add New Subjects</h4>
      </div>
  </div>
  <div class="row">
      <div class="col-md-5">
          <div class="card-box">
            <?php if(session('status')): ?>
              <div class="alert alert-success">
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>
              <h4 class="card-title">Add New</h4>
              <form action="<?php echo e(route('examsubjectadd')); ?>" method="post">
                <?php echo csrf_field(); ?>
                  <div class="form-group">
                      <label>Subject Name</label>
                      <input type="text" class="form-control<?php echo e($errors->has('exam_subject_name') ? ' is-invalid' : ''); ?>" placeholder="Enter new Exam Subject" name="exam_subject_name" value="<?php echo e(old('exam_subject_name')); ?>">
                      <?php if($errors->has('exam_subject_name')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('exam_subject_name')); ?></strong>
                          </span>
                      <?php endif; ?>
                  </div>
                  <div class="text-center m-auto">
                      <button type="submit" class="btn btn-primary">Add Exam Subject</button>
                  </div>
              </form>
          </div>
      </div>
      <div class="col-md-5">
          <div class="card-box">
            <?php if(session('status_1')): ?>
              <div class="alert alert-success">
                <?php echo e(session('status_1')); ?>

              </div>
            <?php endif; ?>
              <h4 class="card-title">List of All Subjects</h4>
              <table class="datatable table table-stripped table-responsive text-center">
                  <thead>
                      <tr>
                          <th>No.</th>
                          <th> Subject Name</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
                    <?php
                      $i=1;
                    ?>
                      <?php $__currentLoopData = $exam_subject_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam_subject_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($exam_subject_name->exam_subject_name); ?></td>
                            <td>
                              <a href="<?php echo e(url('exam/subject/delete')); ?>/<?php echo e($exam_subject_name->id); ?>" class="btn btn-danger"> <i class="fa fa-trash-o"></i></a>
                            </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>