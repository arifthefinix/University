<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('back.student.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
  <?php echo $__env->make('back.student.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
  <div class="row">
      <div class="col-sm-12">
          <h4 class="page-title">Test Your Preparation</h4>
      </div>

  </div>
  <div class="row">
      <div class="offset-md-2 col-md-6">
          <div class="card-box">
              <h4 class="card-title">Select Subject</h4>
              <form action="<?php echo e(route('student_exam_question')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                  <label class="col-form-label col-md-3">Select</label>
                    <div class="col-md-9">
                      <select class="form-control" name="">
                        <option value="">--Select--</option>
                        <option value="">Bangla</option>
                        <option value="">English</option>
                        <option value="">Math</option>
                      </select>
                    </div>

                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary m-auto">Continue</button>
                </div>
              </form>
          </div>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>