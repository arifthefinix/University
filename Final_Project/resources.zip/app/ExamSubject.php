<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExamSubject extends Model
{
    protected $fillable =['exam_subject_name'];
}
