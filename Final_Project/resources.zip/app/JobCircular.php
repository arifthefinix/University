<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobCircular extends Model
{
    protected $fillable=['circular','details'];
}
