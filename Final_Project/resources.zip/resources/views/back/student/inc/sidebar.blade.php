        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <li class="">
                            <a href="{{route('studentdashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a>
                        </li>
                        <li class="">
                            <a href="{{route('studentuniversities')}}"><i class="fa fa-university"></i> Universities</a>
                        </li>
                        <li class="">
                            <a href="{{route('studentapplyunit')}}"><i class="fa fa-university"></i> Units</a>
                        </li>
                        <li class="">
                            <a href="{{route('studentsubjectslist')}}"><i class="fa fa-book"></i>Subjects</a>
                        </li>
                        <li class="">
                            <a href="{{route('student_exam')}}"><i class="fa fa-book"></i>Exam</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
